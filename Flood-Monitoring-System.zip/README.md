
# Flood Monitoring System – IIoT using ESP32 & ThingSpeak 🌊

This project simulates a flood monitoring system using ESP32 microcontroller and sends water level data to ThingSpeak cloud for real-time monitoring. Local alerts are triggered when water levels exceed safe thresholds.

## 📍 Aim
To design and simulate an IIoT-based flood monitoring system that alerts authorities via the cloud and local alarms.

## 🚨 Features
✅ Continuous water level measurement using ultrasonic sensor  
✅ ESP32 WiFi-enabled controller  
✅ Cloud data logging with ThingSpeak  
✅ Local alert system (LED & Buzzer)  
✅ Simulated circuit using Wokwi platform

## 🧰 Components Used
| Component         | Quantity |
|-------------------|----------|
| ESP32 Dev Board   | 1        |
| Ultrasonic Sensor | 1        |
| LED               | 1        |
| Buzzer            | 1        |
| OLED Display      | 1        |

## 🌐 Cloud Platform
**ThingSpeak** – Free IoT analytics platform to visualize real-time water level data.

## 🖥️ Wokwi Simulation
[🔗 Click Here to Open Simulation](https://wokwi.com/projects/YOUR-LINK-HERE)

## 🗂 Project Structure
```bash
Flood-Monitoring-System/
├── Code/
│   └── flood_monitoring.ino
├── Docs/
│   ├── Aim.md
│   ├── ProblemStatement.md
│   ├── Scope.md
│   ├── Components.md
├── Flowchart/
│   └── system_flowchart.png
├── Wokwi/
│   └── wokwi_link.txt
├── Demo/
│   └── demo_video_link.txt
└── README.md
```

## 🚀 Getting Started
1. Open Wokwi simulation link.
2. Update ThingSpeak API key in `flood_monitoring.ino` (already configured).
3. Flash the code on ESP32.
4. View water level updates on ThingSpeak.

## 🎥 Demo Video
[🔗 Watch Demo Here](https://your-demo-link)

## 🧠 Author
L&T EduTech Internship Submission – Your Name
