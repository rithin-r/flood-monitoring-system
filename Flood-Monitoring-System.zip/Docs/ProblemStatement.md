### Problem Statement
Flooding causes catastrophic damage. This project develops a system to monitor dam water levels and alert authorities in real-time.