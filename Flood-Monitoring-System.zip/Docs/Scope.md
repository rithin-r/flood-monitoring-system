### Scope
- Real-time monitoring
- Cloud alerts using ThingSpeak
- Local alarms
- Simulated via Wokwi