### Components
- ESP32 Dev Board
- Ultrasonic Sensor
- LED
- Buzzer
- OLED Display
- Wokwi Simulator
- ThingSpeak