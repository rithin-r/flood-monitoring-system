### Aim
To simulate a flood monitoring system using IIoT principles that alerts authorities via cloud.